# Cab Booking System with Graph Data Structure and Dijkstra's Algorithm

Welcome to the Cab Booking System project! This repository contains code and documentation for a cab booking system that employs a graph data structure and Dijkstra's algorithm for efficient routing. User data is stored in a database to facilitate booking and tracking.
